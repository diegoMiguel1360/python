def area_de_un_triangulo():
    b = int(input('ingrese la base del triangulo: '))
    h = int(input('ingrese la altura de un triangulo: '))
    print((b*h)/2)

def area_de_un_cuadrado():
    l = int(input('ingrese el lado del cuadrado: '))
    print(l*l)

def area_de_un_circulo():
    r = int(input('ingrese el radio del circulo: '))
    print(3.14 * r ** 2)

def area_de_un_rectangulo():
    b = int(input('ingrese la base del rectangulo: '))
    h = int(input('ingrese la altura de un rectangulo: '))
    print(b*h)