
def funcionamiento_regla_de_tres():
  print('z/? * y/x')

def regla_de_tres():
  x = int(input("Ingrese el primer valor: "))
  y = int(input("Ingrese el segundo valor: "))
  z = int(input("Ingrese el tercer valor: "))
  print(z*(x/y))



