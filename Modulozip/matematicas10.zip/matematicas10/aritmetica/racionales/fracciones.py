def division (a,b,c,d):
    res = (a/b)/(c/d)
    return round(res,2)

def multiplicacion(a,b,c,d):
    multi1 = (a/b)*(c/d)
    return round(multi1,2)

def resta(a,b,c,d):
    resta1 = (a/b)-(c/d)
    return round(resta1,2)

def suma(a,b,c,d):
    suma1= (a/b)+(c/d)
    return round(suma1,2)